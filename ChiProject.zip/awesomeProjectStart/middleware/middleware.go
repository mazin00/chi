package middleware

import (
	"context"
	"crypto/rand"
	"fmt"
	"github.com/cockroachdb/errors"
	"net/http"
)

var (
	ErrCtxNotSet = errors.New("key not set in context")
)

const (
	testCtxKey = "testCtx"
)

type TestMid struct {
	id string
}

func TestMiddleware() func(next http.Handler) http.Handler {
	m := func(next http.Handler) http.Handler {
		fn := func(w http.ResponseWriter, r *http.Request) {
			ctx := r.Context()
			mid := TestMid{}
			value, err := mid.SetDefaults(r)
			if err != nil {
				return
			}

			ctx = mid.setTestContext(r.Context(), value)
			next.ServeHTTP(w, r.WithContext(ctx))
		}
		return http.HandlerFunc(fn)
	}
	return m
}

func (v *TestMid) SetDefaults(r *http.Request) (s string, err error) {
	b := make([]byte, 8)
	_, err = rand.Read(b)
	if err != nil {
		return
	}
	s = fmt.Sprintf("%x", b)
	return
}

func (v *TestMid) setTestContext(ctx context.Context, s string) context.Context {
	return context.WithValue(ctx, testCtxKey, s)
}

func GetTestContext(ctx context.Context) (u string, ok bool) {
	v := ctx.Value(testCtxKey)
	u = fmt.Sprintf("%v", v)
	if v == nil {
		return u, false
	}
	return u, true
}

func MustGetContext(ctx context.Context) string {
	u, ok := GetTestContext(ctx)
	if !ok {
		panic(ErrCtxNotSet)
	}
	return u
}
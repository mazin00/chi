package service

import (
	testMiddleware "awesomeProjectStart/middleware"
	"encoding/json"
	"fmt"
	"github.com/go-chi/render"

	"net/http"
)

func RenderJSON(writer http.ResponseWriter, req *http.Request, status int, v interface{}) {
	s := status
	if s != 0 {
		render.Status(req,status)
	}
	render.JSON(writer, req, v)
}

type request struct{
	From	 		string		 	`json:"from"`
	To 				string	 		`json:"to"`
	Subject 		string 			`json:"subject"`
	Body 			interface{} 	`json:"body"`
}

type respond struct{
	From	 		string		 	`json:"from"`
	Body 			interface{} 	`json:"body"`
	Context			interface{}		`json:"ctx"`
}

func First(w http.ResponseWriter, r *http.Request){
	ctx := r.Context()
	params := testMiddleware.MustGetContext(ctx)

	w.Header().Set("Content-Type", "application/json")
	decoder := json.NewDecoder(r.Body)
	var p request
	err := decoder.Decode(&p)
	if err != nil {
		panic(err)
	}
	fmt.Println(p)

	if p.From == "" || (p.Subject == "") || (p.Body == "") || (p.To == ""){
		panic(fmt.Sprintf("error, Field is empty"))
	}

	resp := respond{
		From:    p.From,
		Body:    p.Body,
		Context: params,
	}

	RenderJSON(w,r,http.StatusOK,resp)
}
